import React from 'react'
import RequestDemo from '../Component/Forms/RequestDemo'

const page = () => {
  return (
    <div>
        <RequestDemo/>
    </div>
  )
}

export default page