import React from 'react'
import TryForFree from '../Component/Forms/TryForFree'

const page = () => {
  return (
    <div>
        <TryForFree/>
    </div>
  )
}

export default page