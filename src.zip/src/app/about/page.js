import React from 'react'
import About from '../Component/Company/About/About'

const page = () => {
  return (
    <div>
        <About/>
    </div>
  )
}

export default page