import React from 'react'
import Retail from '../Component/Solutions/Retail/Retail'

const page = () => {
  return (
    <div>
        <Retail/>
    </div>
  )
}

export default page