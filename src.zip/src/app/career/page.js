import React from 'react'
import Carrer from '../Component/Company/Carrer/Carrer'

const page = () => {
  return (
    <div>
        <Carrer/>
    </div>
  )
}

export default page