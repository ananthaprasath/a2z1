import React from 'react'
import VoiceCall from '../Component/Product/VoiceCall/VoiceCall'

const page = () => {
  return (
    <div>
        <VoiceCall/>
    </div>
  )
}

export default page