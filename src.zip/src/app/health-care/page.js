import React from 'react'
import HealthCare from '../Component/Solutions/HealthCare/HealthCare'

const page = () => {
  return (
    <div><HealthCare/></div>
  )
}

export default page