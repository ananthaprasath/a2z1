import React from 'react'
import BulkSms from '../Component/Product/BulkSms/BulkSms'

const page = () => {
  return (
    <div>
      <BulkSms/>
    </div>
  )
}

export default page