import Home from '../Component/Home/Home'


const page = () => {
  return (
    <div>
      <Home/>

    </div>
  )
}

export default page