import React from 'react'
import Media from '../Component/Solutions/Media/Media'

const page = () => {
  return (
    <div>
        <Media/>
    </div>
  )
}

export default page