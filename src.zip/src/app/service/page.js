import React from 'react'
import Service from '../Component/Resources/Services/Service'

const page = () => {
  return (
    <div>
        <Service/>
    </div>
  )
}

export default page