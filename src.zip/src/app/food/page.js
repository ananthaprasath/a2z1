import React from 'react'
import Food from '../Component/Solutions/Food/Food'

const page = () => {
  return (
    <div>
        <Food/>
    </div>
  )
}

export default page