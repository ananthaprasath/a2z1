import React from 'react'
import Faq from '../Component/Resources/Faq/Faq'

const page = () => {
  return (
    <div>
        <Faq/>
    </div>
  )
}

export default page