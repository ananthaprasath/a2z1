import React from 'react'
import Home from './Home'
import Service from './Service'
import Client from '../../Product/Whatsapp/Clients'

const Travel = () => {
  return (
    <div>
        <Home/>
        <Client/>
        <Service/>
    </div>
  )
}

export default Travel