import React from 'react'
import Education from '../Component/Solutions/Education/Education'

const page = () => {
  return (
    <div>
        <Education/>
    </div>
  )
}

export default page