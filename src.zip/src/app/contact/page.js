import React from 'react'
import Contact from '../Component/Company/Contact/Contact'


const page = () => {
  return (
    <div>
        <Contact/>
    </div>
  )
}

export default page