import React from 'react'
import RealEstate from '../Component/Solutions/RealEstate/RealEstate'


const page = () => {
  return (
    <div>
    <RealEstate/>
    </div>
  )
}

export default page