import React from 'react'
import Gaming from '../Component/Solutions/Gaming/Gaming'

const page = () => {
  return (
    <div><Gaming/></div>
  )
}

export default page