import React from 'react'
import Government from '../Component/Solutions/Government/Government'

const page = () => {
  return (
    <div>
        <Government/>
    </div>
  )
}

export default page