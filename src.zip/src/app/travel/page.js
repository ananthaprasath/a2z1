import React from 'react'
import Travel from '../Component/Solutions/Travel/Travel'

const page = () => {
  return (
    <div>
        <Travel/>
    </div>
  )
}

export default page