import WhatsappApi from '../Component/Product/Whatsapp/WhatsappApi'

const page = () => {
  return (
    <div>
        <WhatsappApi/>
    </div>
  )
}

export default page