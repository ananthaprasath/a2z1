import React from 'react'
import RcsSms from '../Component/Product/Rcs/RcsSms'

const page = () => {
  return (
    <div>
        <RcsSms/>
    </div>
  )
}

export default page