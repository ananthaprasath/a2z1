import React from 'react'
import Home from './Home'
import OurService from './OurServices'
import Achievements from './Achievements'
import Industries from '../../Product/BulkSms/Industries'
import Home1 from './Home1'
import Client from '../../Product/Whatsapp/Clients'

const Service = () => {
  return (
    <div>
        <Home/>
        <OurService/>
        <Achievements/>
        <Industries/>
        <Home1/>
        <Client/>
    </div>
  )
}

export default Service